import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'native.dart';

/// Ações de entrada (teclado / direcional / botões do controle).
enum Act { up, down, left, right, accept, cancel, next, prev, details }

/// Camadas sobrepostas (seletor de jogos e editores de imagem).
enum Layer { none, games, editApps, editStore }

const storeTitles = <String>[
  'Dead by Daylight', 'Cyberpunk 2077', 'Arknights: Endfield', 'Warframe', 'Albion Online',
  'War Thunder', 'ARK: Survival Ascended', 'Resident Evil 4', 'Dota 2', 'Once Human',
  'Path of Exile', 'Fortnite', 'Genshin Impact', 'Marvel Rivals', 'Honkai: Star Rail',
  'Zenless Zone Zero', 'Rocket League', 'Call of Duty', 'World of Warcraft', 'Wuthering Waves',
  'Overwatch', 'Neverness to Everness', 'Counter-Strike 2', 'The Forest', 'Far Cry 5',
  'Far Cry 6', 'Battlefield V', 'The Division 2: Red Horizon', 'SMITE 2', 'Phasmophobia',
  'Lost Ark', 'Resident Evil Village', 'Hearts of Iron IV', 'Bodycam', 'Enshrouded',
  'Palworld', 'Warhammer 40,000: Space Marine 2', 'Where Winds Meet', 'Crimson Desert',
  'Watch Dogs 2', 'Project Zomboid', 'Left 4 Dead 2', 'Forza Horizon 5',
  'Halo: The Master Chief Collection', 'Forza Horizon 6', 'World of Warcraft: Midnight', 'R.E.P.O.',
];

String storeCover(int i) => 'assets/covers/${(i + 1).toString().padLeft(2, '0')}.jpg';

class SetRow {
  final String title, icon, kind, sub;
  final String? key;
  final List<String> options;
  const SetRow(this.title, this.icon, this.kind, this.sub, {this.key, this.options = const []});
}

const settingRows = <SetRow>[
  SetRow('Tema', 'brightness', 'choice', 'Claro, escuro ou automático (escuro das 18h às 6h)',
      key: 'theme', options: ['Claro', 'Escuro', 'Auto']),
  SetRow('Meus jogos', 'gamepad', 'games', ''),
  SetRow('Mostrar só jogos selecionados', 'star', 'toggle',
      'Desligado: mostra todos os apps do aparelho', key: 'only'),
  SetRow('Papel de parede', 'folder', 'wall', 'Padrões do tema + imagens que você escolher'),
  SetRow('Imagem do dispositivo', 'search', 'pick',
      'A: escolher uma imagem da galeria · Direita: remover a atual (se for sua)'),
  SetRow('Ícones dos aplicativos', 'gamepad', 'gameicons',
      'Troque o ícone/capa de cada app e jogo da biblioteca · A: editar'),
  SetRow('Ícones da loja', 'store', 'storeicons',
      'Escolha a capa de cada jogo da loja, direto da galeria · A: editar'),
  SetRow('Transparência dos cards', 'info', 'choice', 'Intensidade do vidro fosco, estilo PS5',
      key: 'glass', options: ['Leve', 'Médio', 'Forte']),
  SetRow('Sons de navegação', 'bell', 'toggle', 'Sons estilo PS5 ao navegar, confirmar e voltar',
      key: 'sound'),
  SetRow('Mostrar relógio', 'clock', 'toggle', 'Hora na barra superior', key: 'clock'),
  SetRow('Mostrar bateria', 'battery-100', 'toggle', 'Ícone e porcentagem da bateria',
      key: 'battery'),
  SetRow('Mostrar Bluetooth', 'bluetooth', 'toggle', 'Ícone na barra superior', key: 'bt'),
  SetRow('Mostrar capa inteira', 'gamepad', 'toggle',
      'Exibe a imagem completa nos cards, sem cortar', key: 'fit'),
];

class HomeItem {
  final AppInfo? app;
  final int storeIndex; // -1 quando é um app/jogo
  HomeItem.store(this.storeIndex) : app = null;
  HomeItem.app(AppInfo a)
      : app = a,
        storeIndex = -1;
  bool get isStore => app == null;
  String get title => isStore ? storeTitles[storeIndex] : app!.name;
}

class WallOpt {
  final String key, name;
  const WallOpt(this.key, this.name);
}

const _builtinWalls = <int, String>{
  2: 'Personalizado 2',
  3: 'Oceano',
  4: 'Neon',
  5: 'Floresta',
  6: 'Rosa',
  7: 'Grafite',
  8: 'Ryzen',
  10: 'Personalizado 10',
};

final st = RyzenState();

class RyzenState extends ChangeNotifier with WidgetsBindingObserver {
  late SharedPreferences _p;
  bool ready = false;

  // ---------- navegação ----------
  int tab = 0;
  Layer layer = Layer.none;
  int homeIdx = 0, libIdx = 0, storeIdx = 0, setIdx = 0, pickIdx = 0, editIdx = 0;
  int libCols = 6, storeCols = 6;

  // ---------- configurações ----------
  int themeMode = 0; // 0 claro, 1 escuro, 2 auto
  int glassLevel = 1;
  bool soundOn = true, showClock = true, showBattery = true, showBt = true;
  bool fitImages = true, onlySelected = true;
  String wallKey = 'default';
  List<String> customWalls = [];
  Set<String> selected = {};
  List<String> pinned = [];
  Map<String, String> gameMap = {}, storeMap = {};
  Map<String, int> playSecs = {}, lastPlayed = {};

  // ---------- sistema ----------
  List<AppInfo> apps = [];
  List<AppInfo> shown = [];
  List<HomeItem> homeItems = [];
  int pinnedCount = 0;
  int battery = -1;
  bool charging = false;
  bool night = false;

  Timer? _timer;
  DateTime _appsAt = DateTime.fromMillisecondsSinceEpoch(0);
  String? _launchPkg;
  DateTime? _launchAt;
  bool _sfxReady = false;
  final Map<String, AudioPlayer> _players = {};

  // ---------- tema ----------
  bool get dark => themeMode == 1 || (themeMode == 2 && night);
  Color get txt => dark ? const Color(0xFFF2F4FB) : const Color(0xFF1B2030);
  Color get subTxt => dark ? const Color(0xFF9AA3C4) : const Color(0xFF555A6E);
  double get glassAlpha => const [0.28, 0.42, 0.58][glassLevel];
  double get glassBlur => const [24.0, 40.0, 64.0][glassLevel];
  Color get glass => dark
      ? const Color.fromRGBO(23, 28, 56, 1).withValues(alpha: glassAlpha)
      : Colors.white.withValues(alpha: glassAlpha);
  Color get tileEdge => dark ? const Color(0x40FFFFFF) : const Color(0x99FFFFFF);
  Color get selRow => dark ? const Color(0x33FFFFFF) : const Color(0x66FFFFFF);
  Color get pill => dark ? const Color(0x664A5580) : const Color(0xB3FFFFFF);
  Color get accent => const Color(0xFF4A63D6);
  bool get hasBattery => battery >= 0;

  // ---------- inicialização ----------
  Future<void> init() async {
    WidgetsBinding.instance.addObserver(this);
    _p = await SharedPreferences.getInstance();
    themeMode = _p.getInt('themeMode') ?? 0;
    glassLevel = (_p.getInt('glassLevel') ?? 1).clamp(0, 2).toInt();
    soundOn = _p.getBool('soundOn') ?? true;
    showClock = _p.getBool('showClock') ?? true;
    showBattery = _p.getBool('showBattery') ?? true;
    showBt = _p.getBool('showBt') ?? true;
    fitImages = _p.getBool('fitImages') ?? true;
    onlySelected = _p.getBool('onlySelected') ?? true;
    wallKey = _p.getString('wallKey') ?? 'default';
    customWalls = _p.getStringList('customWalls') ?? [];
    selected = (_p.getStringList('myGames') ?? []).toSet();
    pinned = _p.getStringList('pinnedStore') ?? [];
    gameMap = _strMap(_p.getString('gameMap'));
    storeMap = _strMap(_p.getString('storeMap'));
    playSecs = _intMap(_p.getString('playSecs'));
    lastPlayed = _intMap(_p.getString('lastPlayed'));
    _rebuild();
    ready = true;
    notifyListeners();
    await refreshApps();
    await _tick();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => _tick());
    Future.delayed(const Duration(milliseconds: 900), () => _sfxReady = true);
  }

  Map<String, String> _strMap(String? j) {
    if (j == null) return {};
    try {
      return (jsonDecode(j) as Map).map((k, v) => MapEntry(k.toString(), v.toString()));
    } catch (_) {
      return {};
    }
  }

  Map<String, int> _intMap(String? j) {
    if (j == null) return {};
    try {
      return (jsonDecode(j) as Map).map((k, v) => MapEntry(k.toString(), (v as num).toInt()));
    } catch (_) {
      return {};
    }
  }

  void _saveMap(String key, Map<String, dynamic> m) => _p.setString(key, jsonEncode(m));

  Future<void> refreshApps() async {
    final l = await Native.listApps();
    _appsAt = DateTime.now();
    if (l.isEmpty && apps.isNotEmpty) return;
    apps = l;
    _rebuild();
    notifyListeners();
  }

  Future<void> _tick() async {
    final h = DateTime.now().hour;
    final n = h >= 18 || h < 6;
    final b = await Native.battery();
    final changed = n != night ||
        (b != null && (b.percent != battery || b.charging != charging));
    if (changed) {
      night = n;
      if (b != null) {
        battery = b.percent;
        charging = b.charging;
      }
      notifyListeners();
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s != AppLifecycleState.resumed || !ready) return;
    final pkg = _launchPkg, at = _launchAt;
    if (pkg != null && at != null) {
      final secs = DateTime.now().difference(at).inSeconds;
      _launchPkg = null;
      _launchAt = null;
      if (secs >= 20) {
        playSecs[pkg] = (playSecs[pkg] ?? 0) + secs.clamp(0, 43200).toInt();
        _saveMap('playSecs', playSecs);
      }
    }
    if (DateTime.now().difference(_appsAt).inSeconds > 60) refreshApps();
    _tick();
    notifyListeners();
  }

  // ---------- listas ----------
  void _rebuild() {
    shown = onlySelected ? apps.where((a) => selected.contains(a.package)).toList() : List.of(apps);
    final l = <HomeItem>[];
    for (final t in pinned) {
      final i = storeTitles.indexOf(t);
      if (i >= 0) l.add(HomeItem.store(i));
    }
    pinnedCount = l.length;
    l.addAll(shown.map(HomeItem.app));
    homeItems = l;
    homeIdx = _clampIdx(homeIdx, homeItems.length);
    libIdx = _clampIdx(libIdx, homeItems.length);
    pickIdx = _clampIdx(pickIdx, apps.length);
    editIdx = _clampIdx(editIdx, layer == Layer.editStore ? storeTitles.length : apps.length);
  }

  int _clampIdx(int i, int n) => n == 0 ? 0 : i.clamp(0, n - 1).toInt();

  AppInfo? get lastGame {
    AppInfo? best;
    var bestT = -1;
    for (final a in shown) {
      final t = lastPlayed[a.package] ?? -1;
      if (t > bestT) {
        bestT = t;
        best = a;
      }
    }
    return best ?? (shown.isEmpty ? null : shown.first);
  }

  String hours(AppInfo? a) {
    final secs = a == null ? 0 : (playSecs[a.package] ?? 0);
    final v = (secs / 360).round() / 10;
    return '${v == v.roundToDouble() ? v.toInt().toString() : v.toString()} h';
  }

  // ---------- imagens ----------
  ImageProvider? customImage(String? path) {
    if (path == null) return null;
    final f = File(path);
    return f.existsSync() ? FileImage(f) : null;
  }

  ImageProvider? appImage(AppInfo a) {
    final c = customImage(gameMap[a.package]);
    if (c != null) return c;
    return a.icon == null ? null : MemoryImage(a.icon!);
  }

  ImageProvider? storeImage(int i) =>
      customImage(storeMap[storeTitles[i]]) ?? AssetImage(storeCover(i));

  ImageProvider? itemImage(HomeItem it) =>
      it.isStore ? storeImage(it.storeIndex) : appImage(it.app!);

  // ---------- papel de parede ----------
  List<WallOpt> get wallOptions => [
        const WallOpt('default', 'Padrão'),
        const WallOpt('game', 'Arte do jogo selecionado'),
        for (final e in _builtinWalls.entries)
          WallOpt('asset:assets/wallpapers/${e.key}.jpg', e.value),
        for (final c in customWalls) WallOpt(c, 'Meu: ${_fileName(c)}'),
      ];

  String _fileName(String p) => p.substring(p.lastIndexOf('/') + 1);

  int get wallIndex {
    final i = wallOptions.indexWhere((o) => o.key == wallKey);
    return i < 0 ? 0 : i;
  }

  String get wallName => wallOptions[wallIndex].name;
  bool get wallIsCustom => customWalls.contains(wallKey);

  ImageProvider? get wallProvider {
    if (wallKey == 'default') return null;
    if (wallKey == 'game') {
      if (tab > 1 || homeItems.isEmpty) return null;
      final i = tab == 1 ? libIdx : homeIdx;
      return i < homeItems.length ? itemImage(homeItems[i]) : null;
    }
    if (wallKey.startsWith('asset:')) return AssetImage(wallKey.substring(6));
    return customImage(wallKey);
  }

  void changeWall(int dir) {
    final o = wallOptions;
    wallKey = o[(wallIndex + dir + o.length) % o.length].key;
    _p.setString('wallKey', wallKey);
    notifyListeners();
  }

  Future<String?> pickImage() async {
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery);
      if (x == null) return null;
      final base = await getApplicationSupportDirectory();
      final dir = Directory('${base.path}/imgs')..createSync(recursive: true);
      final safe = x.name.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
      final dest = '${dir.path}/${DateTime.now().millisecondsSinceEpoch}_$safe';
      await File(x.path).copy(dest);
      return dest;
    } catch (_) {
      return null;
    }
  }

  Future<void> pickWall() async {
    final path = await pickImage();
    if (path == null) return;
    if (!customWalls.contains(path)) customWalls.add(path);
    _p.setStringList('customWalls', customWalls);
    wallKey = path;
    _p.setString('wallKey', wallKey);
    notifyListeners();
  }

  void removeCurrentWall() {
    if (!wallIsCustom) return;
    customWalls.remove(wallKey);
    try {
      File(wallKey).deleteSync();
    } catch (_) {}
    _p.setStringList('customWalls', customWalls);
    wallKey = 'default';
    _p.setString('wallKey', wallKey);
    notifyListeners();
  }

  // ---------- ícones / capas personalizados ----------
  bool isMapped(bool store, String key) => (store ? storeMap : gameMap).containsKey(key);

  Future<void> pickFor(bool store, String key) async {
    final path = await pickImage();
    if (path == null) return;
    final m = store ? storeMap : gameMap;
    m[key] = path;
    _saveMap(store ? 'storeMap' : 'gameMap', m);
    notifyListeners();
  }

  void clearMapped(bool store, String key) {
    final m = store ? storeMap : gameMap;
    if (m.remove(key) == null) return;
    _saveMap(store ? 'storeMap' : 'gameMap', m);
    sfx('back');
    notifyListeners();
  }

  // ---------- jogos ----------
  void toggleApp(String pkg) {
    if (!selected.remove(pkg)) selected.add(pkg);
    _p.setStringList('myGames', selected.toList());
    _rebuild();
    notifyListeners();
  }

  void selectAll() {
    selected = apps.map((a) => a.package).toSet();
    _p.setStringList('myGames', selected.toList());
    _rebuild();
    notifyListeners();
  }

  void selectNone() {
    selected = {};
    _p.setStringList('myGames', []);
    _rebuild();
    notifyListeners();
  }

  void togglePin(String title) {
    if (!pinned.remove(title)) pinned.add(title);
    _p.setStringList('pinnedStore', pinned);
    _rebuild();
    notifyListeners();
  }

  void launch(AppInfo a) {
    _launchPkg = a.package;
    _launchAt = DateTime.now();
    lastPlayed[a.package] = DateTime.now().millisecondsSinceEpoch;
    _saveMap('lastPlayed', lastPlayed);
    Native.launch(a.package);
  }

  void activate(int i) {
    if (i < 0 || i >= homeItems.length) return;
    final it = homeItems[i];
    if (it.isStore) {
      tab = 2;
      storeIdx = it.storeIndex;
      sfx('tab');
      notifyListeners();
    } else {
      launch(it.app!);
    }
  }

  // ---------- configurações ----------
  void setTab(int t) {
    if (t == tab) return;
    tab = t;
    sfx('tab');
    notifyListeners();
  }

  int choiceValue(String key) => key == 'theme' ? themeMode : glassLevel;

  bool toggleValue(String key) => switch (key) {
        'clock' => showClock,
        'battery' => showBattery,
        'bt' => showBt,
        'only' => onlySelected,
        'sound' => soundOn,
        _ => fitImages,
      };

  void setMode(int v) {
    themeMode = v;
    _p.setInt('themeMode', v);
    notifyListeners();
  }

  void setGlass(int v) {
    glassLevel = v;
    _p.setInt('glassLevel', v);
    notifyListeners();
  }

  void toggle(String key) {
    switch (key) {
      case 'clock':
        showClock = !showClock;
        _p.setBool('showClock', showClock);
      case 'battery':
        showBattery = !showBattery;
        _p.setBool('showBattery', showBattery);
      case 'bt':
        showBt = !showBt;
        _p.setBool('showBt', showBt);
      case 'sound':
        soundOn = !soundOn;
        _p.setBool('soundOn', soundOn);
        if (soundOn) {
          _sfxReady = true;
          sfx('toggle');
        }
      case 'only':
        onlySelected = !onlySelected;
        _p.setBool('onlySelected', onlySelected);
        _rebuild();
      default:
        fitImages = !fitImages;
        _p.setBool('fitImages', fitImages);
    }
    notifyListeners();
  }

  String subText(int i) {
    final r = settingRows[i];
    if (r.kind == 'games') {
      return '${selected.length} de ${apps.length} jogos selecionados · A: escolher';
    }
    if (r.key == 'battery' && !hasBattery) return 'Bateria não detectada neste dispositivo';
    return r.sub;
  }

  void changeRow(int i, int dir) {
    final r = settingRows[i];
    switch (r.kind) {
      case 'choice':
        final v = (choiceValue(r.key!) + (dir == 0 ? 1 : dir) + 3) % 3;
        if (r.key == 'theme') {
          setMode(v);
        } else {
          setGlass(v);
        }
      case 'wall':
        changeWall(dir == 0 ? 1 : dir);
      case 'games':
        openGames();
      case 'gameicons':
        layer = Layer.editApps;
        editIdx = 0;
        notifyListeners();
      case 'storeicons':
        layer = Layer.editStore;
        editIdx = 0;
        notifyListeners();
      case 'pick':
        if (dir == 0) {
          pickWall();
        } else if (dir > 0) {
          removeCurrentWall();
        }
      default:
        toggle(r.key!);
    }
  }

  void openGames() {
    layer = Layer.games;
    pickIdx = 0;
    notifyListeners();
  }

  void closeLayer() {
    layer = Layer.none;
    sfx('back');
    notifyListeners();
  }

  // ---------- toques ----------
  void tapHome(int i) {
    homeIdx = i;
    sfx('ok');
    activate(i);
    notifyListeners();
  }

  void tapLib(int i) {
    libIdx = i;
    sfx('ok');
    activate(i);
    notifyListeners();
  }

  void tapStore(int i) {
    storeIdx = i;
    sfx('ok');
    togglePin(storeTitles[i]);
  }

  void tapRow(int i) {
    setIdx = i;
    sfx('ok');
    changeRow(i, 0);
    notifyListeners();
  }

  // ---------- entrada (teclado / controle) ----------
  int? _target(Act a, int cur, int n, int cols) {
    switch (a) {
      case Act.left:
        return cur > 0 ? cur - 1 : null;
      case Act.right:
        return cur < n - 1 ? cur + 1 : null;
      case Act.up:
        return cur - cols >= 0 ? cur - cols : null;
      case Act.down:
        if (cur + cols < n) return cur + cols;
        return (cur ~/ cols < (n - 1) ~/ cols) ? n - 1 : null;
      default:
        return null;
    }
  }

  bool _nav(Act a, int n, int cols, int cur, void Function(int) set) {
    if (n == 0) return false;
    final t = _target(a, cur, n, cols);
    if (t == null) return false;
    set(t);
    sfx('move');
    notifyListeners();
    return true;
  }

  void act(Act a) {
    if (!ready) return;
    if (layer != Layer.none) {
      _layerAct(a);
      return;
    }
    if (a == Act.next) {
      if (tab < 3) setTab(tab + 1);
      return;
    }
    if (a == Act.prev) {
      if (tab > 0) setTab(tab - 1);
      return;
    }
    if (a == Act.cancel) {
      if (tab != 0) {
        setTab(0);
      } else {
        sfx('back');
      }
      return;
    }
    const far = 1000000;
    switch (tab) {
      case 0:
        if (a == Act.accept) {
          sfx('ok');
          activate(homeIdx);
        } else {
          _nav(a, homeItems.length, far, homeIdx, (v) => homeIdx = v);
        }
      case 1:
        if (a == Act.accept) {
          sfx('ok');
          activate(libIdx);
        } else {
          _nav(a, homeItems.length, libCols, libIdx, (v) => libIdx = v);
        }
      case 2:
        if (a == Act.accept) {
          sfx('ok');
          togglePin(storeTitles[storeIdx]);
        } else {
          _nav(a, storeTitles.length, storeCols, storeIdx, (v) => storeIdx = v);
        }
      default:
        if (a == Act.accept) {
          sfx('ok');
          changeRow(setIdx, 0);
        } else if (a == Act.left) {
          changeRow(setIdx, -1);
        } else if (a == Act.right) {
          changeRow(setIdx, 1);
        } else if (a == Act.up || a == Act.down) {
          _nav(a, settingRows.length, 1, setIdx, (v) => setIdx = v);
        }
    }
  }

  void _layerAct(Act a) {
    final isGames = layer == Layer.games;
    final n = layer == Layer.editStore ? storeTitles.length : apps.length;
    final cur = isGames ? pickIdx : editIdx;
    if (a == Act.up || a == Act.down) {
      _nav(a, n, 1, cur, (v) => isGames ? pickIdx = v : editIdx = v);
      return;
    }
    if (a == Act.cancel || (a == Act.details && isGames)) {
      closeLayer();
      return;
    }
    if (n == 0) return;
    if (isGames) {
      if (a == Act.accept) {
        sfx('ok');
        toggleApp(apps[pickIdx].package);
      }
      return;
    }
    final store = layer == Layer.editStore;
    final key = store ? storeTitles[editIdx] : apps[editIdx].package;
    if (a == Act.accept) {
      sfx('ok');
      pickFor(store, key);
    } else if (a == Act.right || a == Act.details) {
      clearMapped(store, key);
    }
  }

  // ---------- sons ----------
  Future<void> sfx(String name) async {
    if (!soundOn || !_sfxReady) return;
    try {
      final p = _players.putIfAbsent(name, () => AudioPlayer());
      await p.stop();
      await p.play(AssetSource('sounds/$name.wav'), volume: 0.8);
    } catch (_) {}
  }

  @override
  void dispose() {
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    for (final p in _players.values) {
      p.dispose();
    }
    super.dispose();
  }
}
