import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'state.dart';

/// Escala baseada no design original do tema (1672 x 941).
extension Sx on BuildContext {
  double get s => MediaQuery.sizeOf(this).height / 941;
}

TextStyle ts(BuildContext c, double size, {Color? color, bool bold = false, double? spacing}) {
  return TextStyle(
    fontSize: size * c.s,
    color: color ?? st.txt,
    fontWeight: bold ? FontWeight.bold : FontWeight.normal,
    letterSpacing: spacing == null ? null : spacing * c.s,
    decoration: TextDecoration.none,
  );
}

/// Rola só o necessário para o item ficar visível (como o ListView do QML).
void followIndex(ScrollController c, double start, double extent) {
  if (!c.hasClients) return;
  final p = c.position;
  final top = p.pixels;
  final bottom = top + p.viewportDimension;
  double? target;
  if (start < top) {
    target = start;
  } else if (start + extent > bottom) {
    target = start + extent - p.viewportDimension;
  }
  if (target == null) return;
  target = target.clamp(p.minScrollExtent, p.maxScrollExtent).toDouble();
  c.animateTo(target, duration: const Duration(milliseconds: 150), curve: Curves.easeOut);
}

class SysIcon extends StatelessWidget {
  final String name;
  final double size;
  final bool white;
  const SysIcon(this.name, this.size, {super.key, this.white = false});

  @override
  Widget build(BuildContext context) {
    final dir = (white || st.dark) ? 'icons-white' : 'icons';
    return SvgPicture.asset('assets/$dir/$name.svg', width: size * context.s, height: size * context.s);
  }
}

/// Painel de "vidro fosco": desfoca o que está atrás e aplica uma cor translúcida.
class Glass extends StatelessWidget {
  final double radius;
  final bool frosted;
  final Color? border;
  final double borderWidth;
  final Widget? child;
  const Glass({
    super.key,
    this.radius = 0,
    this.frosted = true,
    this.border,
    this.borderWidth = 1,
    this.child,
  });

  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(radius);
    final sigma = st.glassBlur / 3;
    return Stack(fit: StackFit.expand, children: [
      ClipRRect(
        borderRadius: r,
        child: Stack(fit: StackFit.expand, children: [
          if (frosted)
            BackdropFilter(
              filter: ui.ImageFilter.blur(sigmaX: sigma, sigmaY: sigma),
              child: Container(color: st.glass),
            )
          else
            Container(color: st.glass),
          if (child != null) child!,
        ]),
      ),
      IgnorePointer(
        child: Container(
          decoration: BoxDecoration(
            borderRadius: r,
            border: Border.all(color: border ?? st.tileEdge, width: borderWidth),
          ),
        ),
      ),
    ]);
  }
}

/// Imagem do jogo/capa; se não houver, mostra o título.
class Art extends StatelessWidget {
  final ImageProvider? img;
  final BoxFit fit;
  final String title;
  final double fontSize;
  const Art({super.key, required this.img, required this.fit, required this.title, this.fontSize = 20});

  Widget _label(BuildContext c) => Center(
        child: Padding(
          padding: EdgeInsets.all(8 * c.s),
          child: Text(title, textAlign: TextAlign.center, style: ts(c, fontSize)),
        ),
      );

  @override
  Widget build(BuildContext context) {
    if (img == null) return _label(context);
    return Image(
      image: ResizeImage(img!, width: 600),
      fit: fit,
      width: double.infinity,
      height: double.infinity,
      filterQuality: FilterQuality.medium,
      errorBuilder: (c, e, s) => _label(c),
    );
  }
}

/// Card de jogo / capa da loja (usado em Início e Biblioteca).
Widget itemTile(BuildContext c, HomeItem it, bool cur, {required bool frosted, required double radius, double margin = 8}) {
  final s = c.s;
  return AnimatedScale(
    scale: cur ? 1.05 : 1.0,
    duration: const Duration(milliseconds: 120),
    child: Glass(
      radius: radius * s,
      frosted: frosted,
      border: cur ? Colors.white : st.tileEdge,
      borderWidth: cur ? 4 * s : 1,
      child: Stack(children: [
        Padding(
          padding: EdgeInsets.all(margin * s),
          child: Art(
            img: st.itemImage(it),
            fit: it.isStore ? BoxFit.cover : (st.fitImages ? BoxFit.contain : BoxFit.cover),
            title: it.title,
            fontSize: 21,
          ),
        ),
        if (it.isStore) Positioned(top: 10 * s, right: 10 * s, child: starBadge(s)),
      ]),
    ),
  );
}

Widget starBadge(double s) => Container(
      width: 40 * s,
      height: 40 * s,
      decoration: BoxDecoration(color: st.accent, shape: BoxShape.circle),
      child: Center(child: SysIcon('star', 22, white: true)),
    );

class PillBtn extends StatelessWidget {
  final String text;
  final double w, h, font;
  final bool filled;
  final VoidCallback onTap;
  const PillBtn(this.text, this.onTap, {super.key, this.w = 150, this.h = 46, this.font = 20, this.filled = true});

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: w * s,
        height: h * s,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: filled ? st.accent : Colors.transparent,
          borderRadius: BorderRadius.circular(h * s / 2),
          border: Border.all(color: st.accent, width: 2 * s),
        ),
        child: Text(text, style: ts(context, font, color: filled ? Colors.white : st.txt)),
      ),
    );
  }
}
