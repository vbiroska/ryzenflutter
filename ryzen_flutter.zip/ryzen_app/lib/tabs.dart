import 'package:flutter/material.dart';

import 'state.dart';
import 'ui.dart';

Widget _emptyState(BuildContext c) => Center(
      child: GestureDetector(
        onTap: st.openGames,
        child: Text(
          'Nenhum jogo selecionado.\nToque aqui ou vá em Config › Meus jogos.',
          textAlign: TextAlign.center,
          style: ts(c, 24, color: st.subTxt),
        ),
      ),
    );

// ============================ INÍCIO ============================
class HomeTab extends StatefulWidget {
  const HomeTab({super.key});
  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  final hc = ScrollController();
  int _last = -1;

  @override
  void dispose() {
    hc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final items = st.homeItems;
    final last = st.lastGame;
    if (_last != st.homeIdx) {
      _last = st.homeIdx;
      WidgetsBinding.instance.addPostFrameCallback((_) => followIndex(hc, st.homeIdx * 284 * s, 284 * s));
    }
    return Stack(children: [
      // Banner
      Positioned(
        left: 25 * s,
        top: 16 * s,
        right: (25 + 590 + 20) * s,
        height: 300 * s,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(22 * s),
          child: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF1C2236), Color(0xFF4A63D6)],
              ),
            ),
            child: Stack(children: [
              Positioned(
                top: 40 * s,
                right: 60 * s,
                child: Text('△  ◻\n✕  ◯',
                    style: TextStyle(fontSize: 120 * s, color: const Color(0x33FFFFFF), height: 0.9, decoration: TextDecoration.none)),
              ),
              Positioned(
                left: 54 * s,
                top: 56 * s,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('RYZEN', style: ts(context, 96, color: Colors.white, spacing: 12)),
                  SizedBox(height: 6 * s),
                  Text('Jogue sem limites.', style: ts(context, 22, color: Colors.white)),
                ]),
              ),
              Positioned(
                left: 52 * s,
                top: 226 * s,
                child: GestureDetector(
                  onTap: () => st.setTab(1),
                  child: Container(
                    width: 270 * s,
                    height: 56 * s,
                    decoration: BoxDecoration(
                      color: const Color(0x33FFFFFF),
                      borderRadius: BorderRadius.circular(28 * s),
                      border: Border.all(color: const Color(0x55FFFFFF)),
                    ),
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      SysIcon('play', 24, white: true),
                      SizedBox(width: 10 * s),
                      Text('Explorar Jogos', style: ts(context, 22, color: Colors.white)),
                    ]),
                  ),
                ),
              ),
            ]),
          ),
        ),
      ),
      // Último jogo
      Positioned(
        right: 25 * s,
        top: 16 * s,
        width: 590 * s,
        height: 300 * s,
        child: Glass(
          radius: 22 * s,
          child: Stack(children: [
            Positioned(left: 28 * s, top: 18 * s, child: Text('Último Jogo', style: ts(context, 25))),
            Positioned(
              left: 20 * s,
              top: 56 * s,
              width: 240 * s,
              height: 232 * s,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12 * s),
                child: Container(
                  color: st.dark ? const Color(0x26FFFFFF) : const Color(0x1F000000),
                  child: last == null
                      ? null
                      : Art(
                          img: st.appImage(last),
                          fit: st.fitImages ? BoxFit.contain : BoxFit.cover,
                          title: last.name),
                ),
              ),
            ),
            Positioned(
              left: 285 * s,
              top: 70 * s,
              width: 285 * s,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(last?.name ?? '—', maxLines: 3, overflow: TextOverflow.ellipsis, style: ts(context, 28)),
                SizedBox(height: 14 * s),
                Row(children: [
                  SysIcon('clock', 24),
                  SizedBox(width: 8 * s),
                  Text('Horas: ${st.hours(last)}', style: ts(context, 19)),
                ]),
              ]),
            ),
            Positioned(
              left: 300 * s,
              top: 222 * s,
              child: GestureDetector(
                onTap: () {
                  if (last != null) {
                    st.sfx('ok');
                    st.launch(last);
                  }
                },
                child: Container(
                  width: 250 * s,
                  height: 56 * s,
                  decoration: BoxDecoration(color: st.pill, borderRadius: BorderRadius.circular(28 * s)),
                  child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    SysIcon('play', 24),
                    SizedBox(width: 10 * s),
                    Text('Continuar', style: ts(context, 22, bold: true)),
                  ]),
                ),
              ),
            ),
          ]),
        ),
      ),
      // Destaques
      Positioned(
        left: 40 * s,
        top: 330 * s,
        child: Row(children: [
          SysIcon('gamepad', 38),
          SizedBox(width: 14 * s),
          Text('Destaques', style: ts(context, 26, bold: true)),
        ]),
      ),
      Positioned(
        right: 30 * s,
        top: 336 * s,
        child: GestureDetector(
          onTap: () => st.setTab(1),
          child: Row(children: [
            Text('Ver Todos', style: ts(context, 20)),
            SizedBox(width: 8 * s),
            SysIcon('arrow-right', 24),
          ]),
        ),
      ),
      Positioned(
        left: 30 * s,
        top: 384 * s,
        right: 20 * s,
        height: 335 * s,
        child: items.isEmpty
            ? _emptyState(context)
            : ListView.builder(
                controller: hc,
                scrollDirection: Axis.horizontal,
                itemExtent: 284 * s,
                itemCount: items.length,
                itemBuilder: (c, i) => GestureDetector(
                  onTap: () => st.tapHome(i),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: SizedBox(
                      width: 256 * s,
                      height: 310 * s,
                      child: itemTile(c, items[i], i == st.homeIdx, frosted: true, radius: 16, margin: 8),
                    ),
                  ),
                ),
              ),
      ),
    ]);
  }
}

// ============================ BIBLIOTECA ============================
class LibraryTab extends StatefulWidget {
  const LibraryTab({super.key});
  @override
  State<LibraryTab> createState() => _LibraryTabState();
}

class _LibraryTabState extends State<LibraryTab> {
  final gc = ScrollController();
  int _last = -1;

  @override
  void dispose() {
    gc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final items = st.homeItems;
    return Padding(
      padding: EdgeInsets.all(30 * s),
      child: items.isEmpty
          ? _emptyState(context)
          : LayoutBuilder(builder: (ctx, c) {
              final cols = (c.maxWidth / (235 * s)).ceil().clamp(1, 50).toInt();
              st.libCols = cols;
              final cellH = c.maxWidth / cols * 300 / 235;
              if (_last != st.libIdx) {
                _last = st.libIdx;
                WidgetsBinding.instance
                    .addPostFrameCallback((_) => followIndex(gc, (st.libIdx ~/ cols) * cellH, cellH));
              }
              return GridView.builder(
                controller: gc,
                padding: EdgeInsets.zero,
                gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: 235 * s,
                  childAspectRatio: 235 / 300,
                ),
                itemCount: items.length,
                itemBuilder: (c2, i) => GestureDetector(
                  onTap: () => st.tapLib(i),
                  child: FractionallySizedBox(
                    widthFactor: 205 / 235,
                    heightFactor: 270 / 300,
                    child: itemTile(c2, items[i], i == st.libIdx, frosted: false, radius: 14, margin: 8),
                  ),
                ),
              );
            }),
    );
  }
}

// ============================ LOJA ============================
class StoreTab extends StatefulWidget {
  const StoreTab({super.key});
  @override
  State<StoreTab> createState() => _StoreTabState();
}

class _StoreTabState extends State<StoreTab> {
  final gc = ScrollController();
  int _last = -1;

  @override
  void dispose() {
    gc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return Padding(
      padding: EdgeInsets.all(30 * s),
      child: LayoutBuilder(builder: (ctx, c) {
        final cols = (c.maxWidth / (235 * s)).ceil().clamp(1, 50).toInt();
        st.storeCols = cols;
        final cellH = c.maxWidth / cols * 335 / 235;
        if (_last != st.storeIdx) {
          _last = st.storeIdx;
          WidgetsBinding.instance
              .addPostFrameCallback((_) => followIndex(gc, (st.storeIdx ~/ cols) * cellH, cellH));
        }
        return GridView.builder(
          controller: gc,
          padding: EdgeInsets.zero,
          gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 235 * s,
            childAspectRatio: 235 / 335,
          ),
          itemCount: storeTitles.length,
          itemBuilder: (c2, i) => GestureDetector(
            onTap: () => st.tapStore(i),
            child: FractionallySizedBox(
              widthFactor: 205 / 235,
              heightFactor: 300 / 335,
              child: AnimatedScale(
                scale: i == st.storeIdx ? 1.05 : 1.0,
                duration: const Duration(milliseconds: 120),
                child: Glass(
                  radius: 14 * s,
                  frosted: false,
                  border: i == st.storeIdx ? Colors.white : st.tileEdge,
                  borderWidth: i == st.storeIdx ? 4 * s : 1,
                  child: Stack(children: [
                    Padding(
                      padding: EdgeInsets.all(6 * s),
                      child: Art(img: st.storeImage(i), fit: BoxFit.cover, title: storeTitles[i]),
                    ),
                    if (st.pinned.contains(storeTitles[i]))
                      Positioned(top: 10 * s, right: 10 * s, child: starBadge(s)),
                  ]),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}

// ============================ CONFIG ============================
class SettingsTab extends StatefulWidget {
  const SettingsTab({super.key});
  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  final lc = ScrollController();
  int _last = -1;

  @override
  void dispose() {
    lc.dispose();
    super.dispose();
  }

  Widget _control(BuildContext context, SetRow r) {
    final s = context.s;
    switch (r.kind) {
      case 'choice':
        return Row(mainAxisSize: MainAxisSize.min, children: [
          for (var i = 0; i < r.options.length; i++) ...[
            if (i > 0) SizedBox(width: 8 * s),
            GestureDetector(
              onTap: () => r.key == 'theme' ? st.setMode(i) : st.setGlass(i),
              child: Container(
                width: 110 * s,
                height: 46 * s,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: st.choiceValue(r.key!) == i ? st.accent : Colors.transparent,
                  borderRadius: BorderRadius.circular(23 * s),
                  border: Border.all(color: st.accent, width: 2 * s),
                ),
                child: Text(r.options[i],
                    style: ts(context, 20, color: st.choiceValue(r.key!) == i ? Colors.white : st.txt)),
              ),
            ),
          ],
        ]);
      case 'wall':
        return Row(mainAxisSize: MainAxisSize.min, children: [
          GestureDetector(onTap: () => st.changeWall(-1), child: SysIcon('back', 28)),
          SizedBox(width: 12 * s),
          SizedBox(
            width: 330 * s,
            child: Text('${st.wallName}  (${st.wallIndex + 1}/${st.wallOptions.length})',
                textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(context, 20)),
          ),
          SizedBox(width: 12 * s),
          GestureDetector(onTap: () => st.changeWall(1), child: SysIcon('arrow-right', 28)),
        ]);
      case 'games':
        return PillBtn('Escolher', st.openGames);
      case 'gameicons':
      case 'storeicons':
        return PillBtn('Editar', () => st.changeRow(settingRows.indexOf(r), 0));
      case 'pick':
        return Row(mainAxisSize: MainAxisSize.min, children: [
          PillBtn('Escolher', st.pickWall),
          if (st.wallIsCustom) ...[
            SizedBox(width: 8 * s),
            PillBtn('Remover', st.removeCurrentWall, filled: false),
          ],
        ]);
      default:
        final on = st.toggleValue(r.key!);
        return GestureDetector(
          onTap: () => st.toggle(r.key!),
          child: Container(
            width: 84 * s,
            height: 44 * s,
            decoration: BoxDecoration(
              color: on ? st.accent : const Color(0xFF8A90A8),
              borderRadius: BorderRadius.circular(22 * s),
            ),
            child: AnimatedAlign(
              duration: const Duration(milliseconds: 120),
              alignment: on ? Alignment.centerRight : Alignment.centerLeft,
              child: Container(
                margin: EdgeInsets.all(4 * s),
                width: 36 * s,
                height: 36 * s,
                decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
              ),
            ),
          ),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    if (_last != st.setIdx) {
      _last = st.setIdx;
      WidgetsBinding.instance.addPostFrameCallback((_) => followIndex(lc, st.setIdx * 90 * s, 90 * s));
    }
    return Center(
      child: SizedBox(
        width: 1100 * s,
        height: 690 * s,
        child: Glass(
          radius: 22 * s,
          child: Stack(children: [
            Positioned(left: 40 * s, top: 22 * s, child: Text('Configurações', style: ts(context, 30, bold: true))),
            Positioned(
              left: 30 * s,
              top: 84 * s,
              right: 30 * s,
              bottom: 16 * s,
              child: ListView.builder(
                controller: lc,
                itemExtent: 90 * s,
                itemCount: settingRows.length,
                itemBuilder: (c, i) {
                  final r = settingRows[i];
                  final cur = i == st.setIdx;
                  return Padding(
                    padding: EdgeInsets.only(bottom: 10 * s),
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => st.tapRow(i),
                      child: Container(
                        decoration: BoxDecoration(
                          color: cur ? st.selRow : Colors.transparent,
                          borderRadius: BorderRadius.circular(16 * s),
                          border: Border.all(color: cur ? st.accent : Colors.transparent, width: 3 * s),
                        ),
                        child: Row(children: [
                          SizedBox(width: 24 * s),
                          SysIcon(r.icon, 34),
                          SizedBox(width: 22 * s),
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(r.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(context, 24)),
                                SizedBox(height: 3 * s),
                                Text(st.subText(i),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: ts(context, 16, color: st.subTxt)),
                              ],
                            ),
                          ),
                          _control(context, r),
                          SizedBox(width: 24 * s),
                        ]),
                      ),
                    ),
                  );
                },
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
