import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'state.dart';
import 'ui.dart';

/// Painel modal com lista (usado por "Meus jogos" e pelos editores de ícones/capas).
class ListPanel extends StatefulWidget {
  final String title, subtitle, hint;
  final List<Widget> buttons;
  final int count, index;
  final double rowHeight;
  final Widget Function(BuildContext, int) rowBuilder;
  final void Function(int) onTapRow;
  const ListPanel({
    super.key,
    required this.title,
    required this.subtitle,
    required this.hint,
    required this.buttons,
    required this.count,
    required this.index,
    required this.rowBuilder,
    required this.onTapRow,
    this.rowHeight = 72,
  });

  @override
  State<ListPanel> createState() => _ListPanelState();
}

class _ListPanelState extends State<ListPanel> {
  final sc = ScrollController();
  int _last = -1;

  @override
  void dispose() {
    sc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    final size = MediaQuery.sizeOf(context);
    final ext = (widget.rowHeight + 8) * s;
    if (_last != widget.index) {
      _last = widget.index;
      final i = widget.index;
      WidgetsBinding.instance.addPostFrameCallback((_) => followIndex(sc, i * ext, ext));
    }
    return Stack(children: [
      Positioned.fill(
        child: GestureDetector(onTap: () {}, child: Container(color: const Color(0x99000000))),
      ),
      Center(
        child: Container(
          width: math.min(1100 * s, size.width - 40 * s),
          height: math.min(760 * s, size.height - 40 * s),
          decoration: BoxDecoration(
            color: st.dark ? const Color(0xF2161A2C) : const Color(0xF5FFFFFF),
            borderRadius: BorderRadius.circular(22 * s),
            border: Border.all(color: st.tileEdge),
          ),
          child: Stack(children: [
            Positioned(left: 40 * s, top: 22 * s, child: Text(widget.title, style: ts(context, 30, bold: true))),
            Positioned(left: 40 * s, top: 72 * s, child: Text(widget.subtitle, style: ts(context, 18, color: st.subTxt))),
            Positioned(
              right: 40 * s,
              top: 24 * s,
              child: Row(children: [
                for (var i = 0; i < widget.buttons.length; i++) ...[
                  if (i > 0) SizedBox(width: 8 * s),
                  widget.buttons[i],
                ],
              ]),
            ),
            Positioned(
              left: 30 * s,
              top: 112 * s,
              right: 30 * s,
              bottom: 78 * s,
              child: ListView.builder(
                controller: sc,
                itemExtent: ext,
                itemCount: widget.count,
                itemBuilder: (c, i) {
                  final cur = i == widget.index;
                  return Padding(
                    padding: EdgeInsets.only(bottom: 8 * s),
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => widget.onTapRow(i),
                      child: Container(
                        decoration: BoxDecoration(
                          color: cur ? st.selRow : Colors.transparent,
                          borderRadius: BorderRadius.circular(14 * s),
                          border: Border.all(color: cur ? st.accent : Colors.transparent, width: 3 * s),
                        ),
                        child: widget.rowBuilder(c, i),
                      ),
                    ),
                  );
                },
              ),
            ),
            Positioned(left: 40 * s, bottom: 22 * s, child: Text(widget.hint, style: ts(context, 20, color: st.subTxt))),
          ]),
        ),
      ),
    ]);
  }
}

class LayerView extends StatelessWidget {
  const LayerView({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    if (st.layer == Layer.games) {
      return ListPanel(
        title: 'Meus jogos',
        subtitle: '${st.selected.length} de ${st.apps.length} selecionados',
        hint: 'A  Marcar / Desmarcar        B  Concluir',
        buttons: [
          PillBtn('Todos', st.selectAll, w: 130, h: 44, font: 19, filled: false),
          PillBtn('Nenhum', st.selectNone, w: 130, h: 44, font: 19, filled: false),
          PillBtn('Concluir', st.closeLayer, w: 130, h: 44, font: 19),
        ],
        count: st.apps.length,
        index: st.pickIdx,
        onTapRow: (i) {
          st.pickIdx = i;
          st.sfx('ok');
          st.toggleApp(st.apps[i].package);
        },
        rowBuilder: (c, i) {
          final a = st.apps[i];
          final sel = st.selected.contains(a.package);
          return Row(children: [
            SizedBox(width: 22 * s),
            Container(
              width: 36 * s,
              height: 36 * s,
              decoration: BoxDecoration(
                color: sel ? st.accent : Colors.transparent,
                borderRadius: BorderRadius.circular(9 * s),
                border: Border.all(color: st.accent, width: 2 * s),
              ),
              child: sel ? Center(child: SysIcon('check', 24, white: true)) : null,
            ),
            SizedBox(width: 24 * s),
            Expanded(child: Text(a.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(c, 22))),
            SizedBox(width: 22 * s),
          ]);
        },
      );
    }

    final store = st.layer == Layer.editStore;
    final n = store ? storeTitles.length : st.apps.length;
    return ListPanel(
      title: store ? 'Capas da loja' : 'Ícones dos aplicativos',
      subtitle: 'Escolha a imagem de cada item, direto da galeria do aparelho',
      hint: 'A  Trocar imagem        Direita  Restaurar        B  Fechar',
      buttons: [PillBtn('Concluir', st.closeLayer, w: 130, h: 44, font: 19)],
      count: n,
      index: st.editIdx,
      rowHeight: 76,
      onTapRow: (i) {
        st.editIdx = i;
        st.sfx('ok');
        st.pickFor(store, store ? storeTitles[i] : st.apps[i].package);
      },
      rowBuilder: (c, i) {
        final key = store ? storeTitles[i] : st.apps[i].package;
        final name = store ? storeTitles[i] : st.apps[i].name;
        final img = store ? st.storeImage(i) : st.appImage(st.apps[i]);
        final mapped = st.isMapped(store, key);
        return Row(children: [
          SizedBox(width: 16 * s),
          SizedBox(
            width: 56 * s,
            height: 56 * s,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10 * s),
              child: Art(img: img, fit: BoxFit.cover, title: ''),
            ),
          ),
          SizedBox(width: 20 * s),
          Expanded(child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(c, 22))),
          if (mapped) ...[
            Text('Personalizado', style: ts(c, 17, color: st.subTxt)),
            SizedBox(width: 12 * s),
            GestureDetector(
              onTap: () => st.clearMapped(store, key),
              child: SysIcon('close', 28),
            ),
          ],
          SizedBox(width: 22 * s),
        ]);
      },
    );
  }
}
