import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'overlays.dart';
import 'state.dart';
import 'tabs.dart';
import 'ui.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations(
      [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const RyzenApp());
}

class RyzenApp extends StatefulWidget {
  const RyzenApp({super.key});
  @override
  State<RyzenApp> createState() => _RyzenAppState();
}

class _RyzenAppState extends State<RyzenApp> {
  @override
  void initState() {
    super.initState();
    st.init();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ryzen',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(brightness: Brightness.dark, useMaterial3: true),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> with WidgetsBindingObserver {
  final fn = FocusNode(debugLabel: 'ryzen-root');

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    fn.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) fn.requestFocus();
  }

  KeyEventResult _key(FocusNode node, KeyEvent e) {
    if (e is KeyUpEvent) return KeyEventResult.ignored;
    final k = e.logicalKey;
    Act? a;
    if (k == LogicalKeyboardKey.arrowUp) {
      a = Act.up;
    } else if (k == LogicalKeyboardKey.arrowDown) {
      a = Act.down;
    } else if (k == LogicalKeyboardKey.arrowLeft) {
      a = Act.left;
    } else if (k == LogicalKeyboardKey.arrowRight) {
      a = Act.right;
    } else if (k == LogicalKeyboardKey.enter ||
        k == LogicalKeyboardKey.numpadEnter ||
        k == LogicalKeyboardKey.select ||
        k == LogicalKeyboardKey.gameButtonA) {
      a = Act.accept;
    } else if (k == LogicalKeyboardKey.escape || k == LogicalKeyboardKey.gameButtonB) {
      a = Act.cancel;
    } else if (k == LogicalKeyboardKey.gameButtonRight1 || k == LogicalKeyboardKey.pageDown) {
      a = Act.next;
    } else if (k == LogicalKeyboardKey.gameButtonLeft1 || k == LogicalKeyboardKey.pageUp) {
      a = Act.prev;
    } else if (k == LogicalKeyboardKey.gameButtonY || k == LogicalKeyboardKey.gameButtonX) {
      a = Act.details;
    }
    if (a == null) return KeyEventResult.ignored;
    st.act(a);
    return KeyEventResult.handled;
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: st,
      builder: (context, _) {
        if (!st.ready) return const ColoredBox(color: Colors.black);
        final s = context.s;
        final tabs = <Widget>[HomeTab(), LibraryTab(), StoreTab(), SettingsTab()];
        return PopScope(
          canPop: false,
          onPopInvokedWithResult: (didPop, result) => st.act(Act.cancel),
          child: Focus(
            focusNode: fn,
            autofocus: true,
            onKeyEvent: _key,
            child: Scaffold(
              backgroundColor: Colors.black,
              body: Stack(children: [
                Positioned.fill(child: Background()),
                Positioned(top: 0, left: 0, right: 0, height: 130 * s, child: TopBar()),
                Positioned(top: 130 * s, bottom: 80 * s, left: 0, right: 0, child: tabs[st.tab]),
                Positioned(bottom: 0, left: 0, right: 0, height: 80 * s, child: Footer()),
                if (st.layer != Layer.none) Positioned.fill(child: LayerView()),
              ]),
            ),
          ),
        );
      },
    );
  }
}

class Background extends StatelessWidget {
  const Background({super.key});

  @override
  Widget build(BuildContext context) {
    final dark = st.dark;
    final wall = st.wallProvider;
    return Stack(fit: StackFit.expand, children: [
      DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: dark
                ? const [Color(0xFF161A2C), Color(0xFF1D2340), Color(0xFF12162A)]
                : const [Color(0xFFDFE3F1), Color(0xFFC9CFE6), Color(0xFFE4E7F3)],
          ),
        ),
      ),
      if (wall != null)
        Image(
          image: ResizeImage(wall, width: 1920),
          fit: BoxFit.cover,
          gaplessPlayback: true,
          errorBuilder: (c, e, s) => const SizedBox.shrink(),
        ),
      if (wall != null) ColoredBox(color: dark ? const Color(0x8C050816) : const Color(0x26FFFFFF)),
    ]);
  }
}

class TopBar extends StatefulWidget {
  const TopBar({super.key});
  @override
  State<TopBar> createState() => _TopBarState();
}

class _TopBarState extends State<TopBar> {
  Timer? _t;
  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && st.showClock) setState(() {});
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  String _batteryIcon() {
    if (st.charging) return 'battery-charging';
    final b = st.battery;
    return b > 75 ? 'battery-100' : b > 50 ? 'battery-75' : b > 25 ? 'battery-50' : b > 10 ? 'battery-25' : 'battery-10';
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    const names = ['Início', 'Biblioteca', 'Loja', 'Config'];
    const icons = ['home', 'library', 'store', 'settings'];
    final n = DateTime.now();
    final clock = '${n.hour.toString().padLeft(2, '0')}:${n.minute.toString().padLeft(2, '0')}';
    return Stack(children: [
      Positioned(
        left: 40 * s,
        top: 34 * s,
        child: Text('RYZEN', style: ts(context, 44, spacing: 8)),
      ),
      Align(
        alignment: Alignment.topCenter,
        child: Padding(
          padding: EdgeInsets.only(top: 22 * s, left: 20 * s),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            for (var i = 0; i < 4; i++) ...[
              if (i > 0) SizedBox(width: 24 * s),
              GestureDetector(
                onTap: () => st.setTab(i),
                child: Container(
                  width: 190 * s,
                  height: 84 * s,
                  decoration: BoxDecoration(
                    color: st.tab == i ? st.pill : Colors.transparent,
                    borderRadius: BorderRadius.circular(24 * s),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    SysIcon(icons[i], 34),
                    SizedBox(height: 4 * s),
                    Text(names[i],
                        style: ts(context, 22, bold: st.tab == i)),
                  ]),
                ),
              ),
            ],
          ]),
        ),
      ),
      Positioned(
        right: 36 * s,
        top: 36 * s,
        child: Row(children: [
          SysIcon('wifi', 32),
          SizedBox(width: 26 * s),
          if (st.showBt) ...[SysIcon('bluetooth', 32), SizedBox(width: 26 * s)],
          SysIcon('volume', 32),
          if (st.showBattery && st.hasBattery) ...[
            SizedBox(width: 26 * s),
            SysIcon(_batteryIcon(), 36),
            SizedBox(width: 8 * s),
            Text('${st.battery}%', style: ts(context, 24)),
          ],
          if (st.showClock) ...[
            SizedBox(width: 26 * s),
            Text(clock, style: ts(context, 26)),
          ],
        ]),
      ),
    ]);
  }
}

class Footer extends StatelessWidget {
  const Footer({super.key});

  Widget _btn(BuildContext c, String letter, String label) {
    final s = c.s;
    return Row(children: [
      Container(
        width: 36 * s,
        height: 36 * s,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: st.txt, shape: BoxShape.circle),
        child: Text(letter,
            style: ts(c, 20, bold: true, color: st.dark ? const Color(0xFF14182A) : Colors.white)),
      ),
      SizedBox(width: 10 * s),
      Text(label, style: ts(c, 22)),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.s;
    return Glass(
      border: Colors.transparent,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 34 * s),
        child: Row(children: [
          _btn(context, 'A', st.tab == 2 ? 'Fixar / Desafixar na Início' : 'Selecionar'),
          SizedBox(width: 40 * s),
          _btn(context, 'B', 'Voltar'),
          SizedBox(width: 40 * s),
          Row(children: [
            SysIcon('menu', 34),
            SizedBox(width: 10 * s),
            Text('Menu', style: ts(context, 22)),
          ]),
          const Spacer(),
          Text('Ryzen v2.0', style: ts(context, 22)),
        ]),
      ),
    );
  }
}
