import 'dart:typed_data';
import 'package:flutter/services.dart';

class AppInfo {
  final String name;
  final String package;
  final Uint8List? icon;
  AppInfo(this.name, this.package, this.icon);
}

class BatteryInfo {
  final int percent;
  final bool charging;
  BatteryInfo(this.percent, this.charging);
}

/// Ponte com o Android (MainActivity.kt): lista apps, abre jogo e lê bateria.
class Native {
  static const _ch = MethodChannel('ryzen/native');

  static Future<List<AppInfo>> listApps() async {
    try {
      final r = await _ch.invokeListMethod<dynamic>('listApps') ?? [];
      return r.map((e) {
        final m = e as Map;
        return AppInfo(m['name'] as String, m['package'] as String, m['icon'] as Uint8List?);
      }).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> launch(String pkg) async {
    try {
      await _ch.invokeMethod('launch', pkg);
    } catch (_) {}
  }

  static Future<BatteryInfo?> battery() async {
    try {
      final r = await _ch.invokeMethod<dynamic>('battery');
      if (r is! Map) return null;
      return BatteryInfo(r['percent'] as int, r['charging'] as bool);
    } catch (_) {
      return null;
    }
  }
}
