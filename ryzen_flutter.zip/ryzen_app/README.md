# Ryzen (Flutter)

Port do tema **Ryzen v2.0** (Pegasus Frontend / QML) para um app Android próprio, em Flutter.

## Como gerar o APK

### Opção A — sem instalar nada (GitHub Actions)
1. Crie um repositório no GitHub e suba **todo o conteúdo desta pasta** (inclusive `.github/`).
2. Aba **Actions → Build APK → Run workflow**.
3. Quando terminar, baixe o artefato **ryzen-apk** (dentro dele está o `app-release.apk`).

### Opção B — no seu PC (Flutter + Android SDK instalados)
```bash
flutter create --platforms=android --org com.ryzen --project-name ryzen .
mkdir -p android/app/src/main/kotlin/com/ryzen/ryzen
cp android_patch/MainActivity.kt android/app/src/main/kotlin/com/ryzen/ryzen/MainActivity.kt
cp android_patch/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
flutter pub get
flutter build apk --release
```
O APK sai em `build/app/outputs/flutter-apk/app-release.apk`.

## O que mudou em relação ao tema do Pegasus
- **Jogos** = apps instalados no aparelho (o Pegasus lia coleções/gamelists). Escolha quais aparecem em Config › Meus jogos.
- **Horas jogadas** = tempo em que você ficou fora do Ryzen depois de abrir o jogo por ele (estimativa).
- **Último jogo** = o último aberto pelo Ryzen.
- **Imagens** (wallpaper, ícones, capas) são escolhidas pela galeria; não há mais as pastas `Pictures/Ryzen/...`.
- **Não portado:** troca dos ícones do sistema (ICONES.txt) e varredura de pasta de wallpapers.
- Controle: direcional, A (selecionar), B (voltar), L1/R1 (trocar aba), Y (detalhes). Toque também funciona.
- O manifest inclui o filtro de **tela inicial (HOME)**: dá para definir o Ryzen como launcher. Apague esse bloco se não quiser.
